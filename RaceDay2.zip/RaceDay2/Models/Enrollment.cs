﻿namespace RaceDay.Models;



/// <summary>

/// Records a participant's entry into an event and selected category.

/// </summary>

public class Enrollment

{

    public int EnrollmentId { get; set; }



    public int EventId { get; set; }



    public int ParticipantId { get; set; }



    public int CategoryId { get; set; }



    public DateTime RegistrationDate { get; set; }

        = DateTime.UtcNow;



    public string Status { get; set; } = "Registered";



    public Event Event { get; set; } = null!;



    public Participant Participant { get; set; } = null!;



    public Category Category { get; set; } = null!;



    public Performance? Performance { get; set; }

}


