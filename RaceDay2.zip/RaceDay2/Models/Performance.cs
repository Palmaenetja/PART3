﻿namespace RaceDay.Models;



/// <summary>

/// Stores the finishing time and position for a participant's event.

/// </summary>

public class Performance

{

    public int PerformanceId { get; set; }



    public int ParticipantId { get; set; }



    public int EventId { get; set; }



    public int EnrollmentId { get; set; }



    public TimeSpan? FinishTime { get; set; }



    public int? Position { get; set; }



    public Participant Participant { get; set; } = null!;



    public Event Event { get; set; } = null!;



    public Enrollment Enrollment { get; set; } = null!;

}

