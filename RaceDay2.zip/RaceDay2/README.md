﻿(No subject)
Pal Maenetja

Pal Maenetja
RaceDay – Event Management System

1. Project Overview

RaceDay is a web-based event management system designed for the South African road running, walking, and cycling community.

The system provides a central platform where event organisers can create and manage sporting events, manage event categories, monitor participant registrations, and record race results.

Participants can browse upcoming events, register for events, view their enrolments, and track their performance history.

The main purpose of RaceDay is to improve event management by reducing manual paperwork, spreadsheets, and disconnected communication methods.

2. Project Objectives

The objectives of RaceDay are to:

Provide an online platform for managing sporting events.
Allow organisers to create, update, and manage events.
Allow participants to browse and register for events.
Manage event categories and participant enrolments.
Record and display race results.
Allow participants to track their performance history.
Provide secure authentication and role-based access.
Support event image uploads using Azure Blob Storage.
Provide a responsive and user-friendly interface.
3. Technologies Used

The project uses the following technologies:

Technology

Purpose

C#

Main programming language

ASP.NET Core Web API

Backend application

ASP.NET Core MVC

Frontend application

.NET 9

Application framework

Entity Framework Core 9

Database management

Microsoft SQL Server

Database

HTML5

Web page structure

CSS3

Website styling

Bootstrap 5

Responsive user interface

JavaScript

Client-side functionality

Azure Blob Storage

Image and file storage

Docker

Application containerisation

Git and GitHub

Version control

xUnit

Application testing

4. System Architecture

RaceDay uses a multi-layered architecture consisting of:

Backend – RaceDay.Api

The API handles:

User registration and authentication.
Event management.
Category management.
Participant enrolments.
Race results.
Database operations.
Azure Blob Storage integration.
Frontend – RaceDay.Mvc

The MVC application provides:

Home page and event browsing.
Login and registration pages.
Participant dashboard.
Organiser dashboard.
Event management pages.
Participant profile pages.
Event enrolment and result pages.
The MVC application communicates with the backend API through HTTP requests.

Database

Microsoft SQL Server stores application information, including:

Users
Participants
Events
Categories
Enrolments
Performances
Cloud Storage

Azure Blob Storage is used to store uploaded event images and other supported files.

5. Project Structure

The solution is organised as follows:

RaceDay/

│

├── RaceDay.Api/

│   ├── Controllers/

│   ├── Data/

│   ├── DTOs/

│   ├── Models/

│   ├── Services/

│   ├── Migrations/

│   ├── Properties/

│   ├── appsettings.json

│   └── Program.cs

│

├── RaceDay.Mvc/

│   ├── Controllers/

│   ├── Models/

│   ├── Views/

│   │   ├── Account/

│   │   ├── Events/

│   │   ├── Home/

│   │   ├── Organiser/

│   │   ├── Participant/

│   │   ├── Profile/

│   │   └── Shared/

│   ├── wwwroot/

│   │   ├── css/

│   │   ├── js/

│   │   └── lib/

│   ├── Dockerfile

│   ├── appsettings.json

│   └── Program.cs

│

├── RaceDay.Tests/

│

├── docker-compose.yml

├── RaceDay.sln

└── README.md

6. User Roles

RaceDay supports two main user roles.

Organiser

Organisers can:

Create sporting events.
Edit and manage events.
Manage event categories.
View participant enrolments.
Record and manage race results.
Participant

Participants can:

Register for an account.
Log in securely.
Browse upcoming events.
Enrol in events.
View their enrolments.
View their race results.
Track their performance history.
7. Installation and Setup

Prerequisites

Before running the project, install:

Visual Studio 2022.
.NET 9 SDK.
Microsoft SQL Server.
SQL Server Management Studio (SSMS), if required.
Docker Desktop.
Git.
An Azure Storage Account for cloud file storage.
Step 1: Clone the repository

Open a terminal and run:

git clone YOUR_GITHUB_REPOSITORY_URL

Navigate to the project directory:

cd RaceDay

Step 2: Restore dependencies

Run:

dotnet restore

Step 3: Configure the database

Open:

RaceDay.Api/appsettings.json

Configure the SQL Server connection string:

{

  "ConnectionStrings": {

    "RaceDay": "Server=YOUR_SERVER_NAME;Database=RaceDayDb;Trusted_Connection=True;TrustServerCertificate=True;"

  }

}

Replace YOUR_SERVER_NAME with your actual SQL Server instance.

Step 4: Configure Azure Blob Storage

Configure Azure Blob Storage using User Secrets or environment variables.

For local development, open a terminal in the RaceDay.Api directory:

dotnet user-secrets init

Then add the Azure connection string:

dotnet user-secrets set "AzureBlobStorage:ConnectionString" "YOUR_AZURE_CONNECTION_STRING"

Configure the container name:

"AzureBlobStorage": {

  "ContainerName": "raceday-images"

}

Never commit real connection strings, passwords, or storage account keys to GitHub.

Step 5: Apply database migrations

Open a terminal in the RaceDay.Api directory and run:

dotnet ef database update

If the EF Core tools are not installed:

dotnet tool install --global dotnet-ef --version 9.0.0

Step 6: Configure the MVC API URL

Open:

RaceDay.Mvc/appsettings.json

Set the API address to the actual HTTPS address used by your API:

{

  "ApiSettings": {

    "BaseUrl": "https://localhost:YOUR_API_PORT/"

  }

}

Replace YOUR_API_PORT with the port configured in the API launch settings.

8. Running the Application

Run the API

Open the RaceDay solution in Visual Studio.
Set RaceDay.Api as the startup project.
Press F5 or click Start.
Run the MVC application

Set RaceDay.Mvc as the startup project.
Ensure the API is also running.
Press F5 or click Start.
Open the MVC application in your browser.
The MVC frontend communicates with the running API.

9. Docker Configuration

Docker is used to package and run the RaceDay application in containers.

Ensure Docker Desktop is installed and running.

Build the MVC Docker image from the RaceDay.Mvc directory:

docker build -t raceday-mvc .

Build the API image from the RaceDay.Api directory:

docker build -t raceday-api .

To start the application using Docker Compose, navigate to the solution directory and run:

docker compose up --build

To stop the containers:

docker compose down

Ensure the Docker Compose configuration contains the correct database, API, and MVC service settings.

10. Testing

RaceDay includes a test project called RaceDay.Tests.

The test project uses xUnit for automated testing.

To execute the tests, run:

dotnet test

Testing should cover:

User registration.
User authentication.
Event creation and updating.
Category management.
Participant enrolments.
Result management.
API responses.
Role-based authorisation.
11. Security

The application uses security measures including:

Password hashing.
Cookie-based authentication.
Role-based authorisation.
Protected organiser functionality.
Secure configuration of sensitive information.
Server-side input validation.
HTTPS for application communication.
Azure Storage credentials must be kept outside the source code.

12. Version Control

Git and GitHub are used to manage the project’s source code and development history.

The project uses meaningful commits to document development progress, including:

Project setup.
MVC configuration.
API integration.
Authentication.
Organiser functionality.
Participant functionality.
Database integration.
Azure Blob Storage.
Docker configuration.
Testing and documentation.
13. Future Improvements

Possible future improvements include:

Live weather information for event locations.
Interactive event route maps.
Email notifications.
Online payment integration.
Advanced event analytics.
Improved participant performance reports.
Mobile-friendly enhancements.
14. Conclusion

RaceDay provides a centralised digital solution for managing sporting events in South Africa. By combining ASP.NET Core Web API, MVC, SQL Server, Azure Blob Storage, and Docker, the system aims to improve event administration and provide a convenient experience for both event organisers and participants.

The application is designed to make event registration, management, and performance tracking easier, more efficient, and more accessible.


