﻿using Microsoft.EntityFrameworkCore;
using RaceDay.Models;

namespace RaceDay.Data;



/// <summary>

/// Provides EF Core access to the RaceDay SQL Server database.

/// </summary>

public class RaceDayDbContext : DbContext

{

    public RaceDayDbContext(DbContextOptions<RaceDayDbContext> options)

        : base(options)

    {

    }



    public DbSet<User> Users => Set<User>();

    public DbSet<Participant> Participants => Set<Participant>();

    public DbSet<Event> Events => Set<Event>();

    public DbSet<Category> Categories => Set<Category>();

    public DbSet<Enrollment> Enrollments => Set<Enrollment>();

    public DbSet<Performance> Performances => Set<Performance>();



    protected override void OnModelCreating(ModelBuilder modelBuilder)

    {

        base.OnModelCreating(modelBuilder);



        modelBuilder.Entity<User>()

            .HasIndex(u => u.Username).IsUnique();



        modelBuilder.Entity<User>()

            .HasIndex(u => u.Email).IsUnique();



        modelBuilder.Entity<User>()

            .ToTable(t => t.HasCheckConstraint(

                "CK_Users_Role",

                "[Role] IN ('Organiser', 'Participant')"));



        modelBuilder.Entity<User>()

            .HasOne(u => u.Participant)

            .WithOne(p => p.User)

            .HasForeignKey<Participant>(p => p.UserId);



        modelBuilder.Entity<Event>()

            .HasOne(e => e.Organizer)

            .WithMany(u => u.OrganisedEvents)

            .HasForeignKey(e => e.OrganizerId)

            .OnDelete(DeleteBehavior.Restrict);



        modelBuilder.Entity<Event>()

            .Property(e => e.DistanceKm)

            .HasPrecision(8, 2);



        modelBuilder.Entity<Event>()

            .ToTable(t => t.HasCheckConstraint(

                "CK_Events_EventType",

                "[EventType] IN ('Run', 'Walk', 'Cycle')"));



        modelBuilder.Entity<Category>()

            .HasOne(c => c.Event)

            .WithMany(e => e.Categories)

            .HasForeignKey(c => c.EventId);



        modelBuilder.Entity<Enrollment>()

            .HasIndex(e => new { e.EventId, e.ParticipantId })

            .IsUnique();



        modelBuilder.Entity<Enrollment>()

            .HasOne(e => e.Category)

            .WithMany(c => c.Enrollments)

            .HasForeignKey(e => e.CategoryId)

            .OnDelete(DeleteBehavior.Restrict);



        modelBuilder.Entity<Performance>()

            .HasIndex(p => p.EnrollmentId).IsUnique();



        modelBuilder.Entity<Performance>()

            .HasOne(p => p.Enrollment)

            .WithOne(e => e.Performance)

            .HasForeignKey<Performance>(p => p.EnrollmentId)

            .OnDelete(DeleteBehavior.Restrict);



        modelBuilder.Entity<Performance>()

            .Property(p => p.FinishTime)

            .HasColumnType("time");

    }

}
