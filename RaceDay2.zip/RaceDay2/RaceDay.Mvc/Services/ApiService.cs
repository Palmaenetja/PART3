﻿using System.Net.Http.Headers;
namespace RaceDay.Mvc.Services;
/// <summary>
/// Provides HTTP communication between the MVC application
/// and the RaceDay Web API.
/// </summary>
public class ApiService
{
    private readonly HttpClient _http;
    private readonly IHttpContextAccessor _httpContextAccessor;
    public ApiService(
    HttpClient http,
    IHttpContextAccessor httpContextAccessor)
    {
        _http = http;
        _httpContextAccessor = httpContextAccessor;
    }
    private HttpRequestMessage CreateRequest(
    HttpMethod method,
    string endpoint)
    {
        var request = new HttpRequestMessage(method, endpoint);
        var apiCookie = _httpContextAccessor
        .HttpContext?.Session.GetString("ApiCookie");
        if (!string.IsNullOrWhiteSpace(apiCookie))
        {
            request.Headers.Add("Cookie", apiCookie);
        }
        return request;
    }
    public async Task<HttpResponseMessage> GetAsync(string endpoint)
    {
        return await _http.SendAsync(
        CreateRequest(HttpMethod.Get, endpoint));
    }
    public async Task<HttpResponseMessage> PostAsync<T>(
    string endpoint,
    T data)
    {
        var request = CreateRequest(HttpMethod.Post, endpoint);
        request.Content = JsonContent.Create(data);
        return await _http.SendAsync(request);
    }
    public async Task<HttpResponseMessage> PutAsync<T>(
    string endpoint,
    T data)
    {
        var request = CreateRequest(HttpMethod.Put, endpoint);
        request.Content = JsonContent.Create(data);
        return await _http.SendAsync(request);
    }
    public async Task<HttpResponseMessage> DeleteAsync(
    string endpoint)
    {
        return await _http.SendAsync(
        CreateRequest(HttpMethod.Delete, endpoint));
    }
    public async Task<HttpResponseMessage> PostMultipartAsync(
    string endpoint,
    IFormFile file,
    string fieldName = "file")
    {
        var request = CreateRequest(HttpMethod.Post, endpoint);
        var content = new MultipartFormDataContent();
        var stream = file.OpenReadStream();
        var fileContent = new StreamContent(stream);
        fileContent.Headers.ContentType =
        new MediaTypeHeaderValue(
        file.ContentType ?? "application/octet-stream");
        content.Add(fileContent, fieldName, file.FileName);
        request.Content = content;
        return await _http.SendAsync(request);
    }
}