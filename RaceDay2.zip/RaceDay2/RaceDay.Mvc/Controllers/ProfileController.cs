﻿using Microsoft.AspNetCore.Authorization;

using Microsoft.AspNetCore.Mvc;

using System.Text.Json;



namespace RaceDay.Mvc.Controllers;



[Authorize]

public class ProfileController : Controller

{

    private readonly HttpClient _httpClient;



    public ProfileController(IHttpClientFactory factory)

    {

        _httpClient = factory.CreateClient("RaceDayApi");

    }



    // Display logged-in user's profile

    public async Task<IActionResult> Index()

    {

        var response = await _httpClient.GetAsync("api/profile/me");



        if (!response.IsSuccessStatusCode)

        {

            ViewBag.Error = "Unable to load profile.";

            return View();

        }



        var profile = await response.Content

            .ReadFromJsonAsync<JsonElement>();



        return View(profile);

    }

}



