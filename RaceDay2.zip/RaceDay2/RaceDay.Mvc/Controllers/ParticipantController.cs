﻿using System.Text.Json;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Services;
namespace RaceDay.Mvc.Controllers;
[Authorize(Roles = "Participant")]
public class ParticipantController : Controller
{
    private readonly ApiService _api;
    public ParticipantController(ApiService api)
    {
        _api = api;
    }
    public async Task<IActionResult> Dashboard()
    {
        var response = await _api.GetAsync("api/events");
        if (!response.IsSuccessStatusCode)
        {
            ViewBag.Error =
            "Unable to load upcoming events.";
            return View(new List<JsonElement>());
        }
        var events = await response.Content
        .ReadFromJsonAsync<List<JsonElement>>()
        ?? new List<JsonElement>();
        return View(events);
    }
    public async Task<IActionResult> MyEnrollments()
    {
        var response = await _api.GetAsync(
        "api/enrollments/my");
        if (!response.IsSuccessStatusCode)
        {
            ViewBag.Error =
            "Unable to load your enrolments.";
            return View(new List<JsonElement>());
        }
        var enrollments = await response.Content
        .ReadFromJsonAsync<List<JsonElement>>()
        ?? new List<JsonElement>();
        return View(enrollments);
    }
    public async Task<IActionResult> MyResults()
    {
        var response = await _api.GetAsync(
        "api/results/my");
        if (!response.IsSuccessStatusCode)
        {
            ViewBag.Error =
            "Unable to load your results.";
            return View(new List<JsonElement>());
        }
        var results = await response.Content
        .ReadFromJsonAsync<List<JsonElement>>()
        ?? new List<JsonElement>();
        return View(results);
    }
}