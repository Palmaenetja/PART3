﻿using RaceDay.Models;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Models;
using RaceDay.Mvc.Services;
namespace RaceDay.Mvc.Controllers;
public class AccountController : Controller
{
    private readonly ApiService _api;
    public AccountController(ApiService api)
    {
        _api = api;
    }
    [AllowAnonymous]
    public IActionResult Login()
    {
        return View();
    }
    [HttpPost]
    [AllowAnonymous]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        if (!ModelState.IsValid)
            return View(model);
        var response = await _api.PostAsync(
        "api/auth/login",
        new
        {
            model.Email,
            model.Password
        });
        if (!response.IsSuccessStatusCode)
        {
            ModelState.AddModelError(
            "",
            "Invalid email or password.");
            return View(model);
        }
        if (!response.Headers.TryGetValues(
        "Set-Cookie", out var cookies))
        {
            ModelState.AddModelError(
            "",
            "The API did not return an authentication cookie.");
            return View(model);
        }
        var apiCookie = cookies
        .FirstOrDefault(c => c.StartsWith(
        "RaceDay.Session=", StringComparison.Ordinal));
        if (apiCookie == null)
        {
            ModelState.AddModelError(
            "",
            "Could not establish an API session.");
            return View(model);
        }
        var cookieValue = apiCookie.Split(';')[0];
        HttpContext.Session.SetString("ApiCookie", cookieValue);
        // Obtain the role from the API or its authenticated profile endpoint.
        var profileResponse = await _api.GetAsync("api/profile/me");
        if (!profileResponse.IsSuccessStatusCode)
        {
            HttpContext.Session.Clear();
            ModelState.AddModelError(
            "",
            "Could not retrieve your account details.");
            return View(model);
        }
        var profile = await profileResponse.Content
        .ReadFromJsonAsync<LoginProfile>();
        if (profile == null ||
        (profile.Role != "Organiser" &&
        profile.Role != "Participant"))
        {
            HttpContext.Session.Clear();
            ModelState.AddModelError(
            "",
            "Your account role could not be verified.");
            return View(model);
        }
        var claims = new List<Claim>
{
new(ClaimTypes.Name, profile.Email ?? model.Email),
new(ClaimTypes.Role, profile.Role)
};
        if (profile.UserId > 0)
        {
            claims.Add(new Claim(
            ClaimTypes.NameIdentifier,
            profile.UserId.ToString()));
        }
        var identity = new ClaimsIdentity(
        claims,
        CookieAuthenticationDefaults.AuthenticationScheme);
        var principal = new ClaimsPrincipal(identity);
        await HttpContext.SignInAsync(
        CookieAuthenticationDefaults.AuthenticationScheme,
        principal);
        if (profile.Role == "Organiser")
            return RedirectToAction(
            "Dashboard", "Organiser");
        return RedirectToAction(
        "Dashboard", "Participant");
    }
    [HttpGet]
    [AllowAnonymous]
    public IActionResult Register()
    {
        return View();
    }
    [HttpPost]
    [AllowAnonymous]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Register(
    RegisterViewModel model)
    {
        if (!ModelState.IsValid)
            return View(model);
        if (model.Role != "Participant" &&
        model.Role != "Organiser")
        {
            ModelState.AddModelError(
            nameof(model.Role),
            "Select a valid account role.");
            return View(model);
        }
        if (model.Role == "Participant" &&
        (string.IsNullOrWhiteSpace(model.FirstName) ||
        string.IsNullOrWhiteSpace(model.LastName)))
        {
            ModelState.AddModelError(
            "",
            "Participants must provide their first and last names.");
            return View(model);
        }
        var response = await _api.PostAsync(
        "api/auth/register",
        new
        {
            model.Email,
            model.Password,
            model.Role,
            model.FirstName,
            model.LastName
        });
        if (!response.IsSuccessStatusCode)
        {
            ModelState.AddModelError(
            "",
            "Registration failed. Please check your details.");
            return View(model);
        }
        TempData["Success"] =
        "Registration successful. Please log in.";
        return RedirectToAction(nameof(Login));
    }
    [HttpPost]
    [Authorize]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Logout()
    {
        try
        {
            await _api.PostAsync(
            "api/auth/logout",
            new { });
        }
        finally
        {
            HttpContext.Session.Clear();
            await HttpContext.SignOutAsync(
            CookieAuthenticationDefaults.AuthenticationScheme);
        }
        return RedirectToAction("Index", "Home");
    }
    [AllowAnonymous]
    public IActionResult AccessDenied()
    {
        return View();
    }
    private class LoginProfile
    {
        public int UserId { get; set; }
        public string? Email { get; set; }
        public string Role { get; set; } = "";
    }
}