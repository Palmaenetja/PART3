﻿using Microsoft.AspNetCore.Authorization;

using Microsoft.AspNetCore.Mvc;

using System.Text.Json;



namespace RaceDay.Mvc.Controllers;



[Authorize]

public class EventsController : Controller

{

    private readonly HttpClient _httpClient;



    public EventsController(IHttpClientFactory factory)

    {

        _httpClient = factory.CreateClient("RaceDayApi");

    }



    // Display all events

    [AllowAnonymous]

    public async Task<IActionResult> Index()

    {

        var response = await _httpClient.GetAsync("api/events");



        if (!response.IsSuccessStatusCode)

        {

            ViewBag.Error = "Unable to load events.";

            return View(new List<JsonElement>());

        }



        var events = await response.Content

            .ReadFromJsonAsync<List<JsonElement>>();



        return View(events ?? new List<JsonElement>());

    }



    // Display event details

    [AllowAnonymous]

    public async Task<IActionResult> Details(int id)

    {

        var response = await _httpClient.GetAsync($"api/events/{id}");



        if (!response.IsSuccessStatusCode)

            return NotFound();



        var eventDetails = await response.Content

            .ReadFromJsonAsync<JsonElement>();



        return View(eventDetails);

    }



    // Display event creation page

    [Authorize(Roles = "Organiser")]

    public IActionResult Create()

    {

        return View();

    }



    // Create event

    [HttpPost]

    [ValidateAntiForgeryToken]

    [Authorize(Roles = "Organiser")]

    public async Task<IActionResult> Create(JsonElement model)

    {

        var response = await _httpClient.PostAsJsonAsync(

            "api/events", model);



        if (response.IsSuccessStatusCode)

            return RedirectToAction(nameof(Index));



        ModelState.AddModelError("", "Unable to create event.");

        return View(model);

    }

    /// <summary>
    /// Uploads a banner image for an event owned by the organiser.
    /// </summary>
    


}



