﻿using System.Text.Json;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Services;
namespace RaceDay.Mvc.Controllers;
[Authorize(Roles = "Organiser")]
public class OrganiserController : Controller
{
    private readonly ApiService _api;
    public OrganiserController(ApiService api)
    {
        _api = api;
    }
    public async Task<IActionResult> Dashboard()
    {
        var response = await _api.GetAsync("api/events");
        if (!response.IsSuccessStatusCode)
        {
            ViewBag.Error =
            "Unable to load your events. Please try again.";
            return View(new List<JsonElement>());
        }
        var events = await response.Content
        .ReadFromJsonAsync<List<JsonElement>>()
        ?? new List<JsonElement>();
        return View(events);
    }
}