﻿using System.ComponentModel.DataAnnotations;
namespace RaceDay.Mvc.Models;
public class RegisterViewModel
{
    [Required]
    [EmailAddress]
    public string Email { get; set; } = "";
    [Required]
    [MinLength(8)]
    [DataType(DataType.Password)]
    public string Password { get; set; } = "";
    [Required]
    [Compare(nameof(Password))]
    [DataType(DataType.Password)]
    public string ConfirmPassword { get; set; } = "";
    [Required]
    public string Role { get; set; } = "Participant";
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
}