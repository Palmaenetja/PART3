﻿public class CreateResultDto

{

    [System.ComponentModel.DataAnnotations.Range(1, int.MaxValue)]

    public int EnrollmentId { get; set; }



    public TimeSpan FinishTime { get; set; }



    [System.ComponentModel.DataAnnotations.Range(1, int.MaxValue)]

    public int Position { get; set; }

}
