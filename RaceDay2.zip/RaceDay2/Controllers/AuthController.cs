﻿using System.Security.Claims;

using Microsoft.AspNetCore.Authentication;

using Microsoft.AspNetCore.Authentication.Cookies;

using Microsoft.AspNetCore.Authorization;

using Microsoft.AspNetCore.Identity;

using Microsoft.AspNetCore.Mvc;

using Microsoft.EntityFrameworkCore;
using RaceDay.Data;
using RaceDay.DTOs;
using RaceDay.Models;

namespace RaceDay.Controllers;



/// <summary>

/// Handles registration, login and logout for RaceDay accounts.

/// </summary>

[ApiController]

[Route("api/auth")]

public class AuthController : ControllerBase

{

    private readonly RaceDayDbContext _db;

    private readonly IPasswordHasher<User> _hasher;



    public AuthController(

        RaceDayDbContext db,

        IPasswordHasher<User> hasher)

    {

        _db = db;

        _hasher = hasher;

    }



    /// <summary>

    /// Registers a new organiser or participant account.

    /// </summary>

    [AllowAnonymous]

    [HttpPost("register")]

    public async Task<IActionResult> Register(RegisterDto dto)

    {

        var role = dto.Role.Trim();



        if (role is not ("Organiser" or "Participant"))

            return BadRequest("Role must be Organiser or Participant.");



        if (await _db.Users.AnyAsync(u =>

            u.Username == dto.Username || u.Email == dto.Email))

        {

            return Conflict("Username or email already exists.");

        }



        if (role == "Participant" &&

            (dto.DateOfBirth is null ||

             dto.DateOfBirth.Value > DateOnly.FromDateTime(DateTime.UtcNow)))

        {

            return BadRequest(

                "A valid date of birth is required for participants.");

        }



        var user = new User

        {

            Username = dto.Username.Trim(),

            Email = dto.Email.Trim(),

            Role = role

        };



        user.PasswordHash = _hasher.HashPassword(user, dto.Password);



        _db.Users.Add(user);



        if (role == "Participant")

        {

            user.Participant = new Participant

            {

                FirstName = dto.FirstName.Trim(),

                LastName = dto.LastName.Trim(),

                DateOfBirth = dto.DateOfBirth!.Value

            };

        }



        await _db.SaveChangesAsync();



        return Created("/api/profile/me", new

        {

            user.UserId,

            user.Username,

            user.Email,

            user.Role

        });

    }



    /// <summary>

    /// Authenticates a registered user and issues a cookie.

    /// </summary>

    [AllowAnonymous]

    [HttpPost("login")]

    public async Task<IActionResult> Login(LoginDto dto)

    {

        var user = await _db.Users.SingleOrDefaultAsync(

            u => u.Username == dto.Username);



        if (user is null)

            return Unauthorized("Invalid username or password.");



        var verification = _hasher.VerifyHashedPassword(

            user, user.PasswordHash, dto.Password);



        if (verification == PasswordVerificationResult.Failed)

            return Unauthorized("Invalid username or password.");



        var claims = new List<Claim>

        {

            new(ClaimTypes.NameIdentifier, user.UserId.ToString()),

            new(ClaimTypes.Name, user.Username),

            new(ClaimTypes.Role, user.Role)

        };



        var identity = new ClaimsIdentity(

            claims, CookieAuthenticationDefaults.AuthenticationScheme);



        await HttpContext.SignInAsync(

            CookieAuthenticationDefaults.AuthenticationScheme,

            new ClaimsPrincipal(identity));



        HttpContext.Session.SetInt32("UserId", user.UserId);

        HttpContext.Session.SetString("Role", user.Role);



        return Ok(new

        {

            message = "Login successful.",

            user.UserId,

            user.Username,

            user.Role

        });

    }



    /// <summary>

    /// Signs the current user out and clears the session.

    /// </summary>

    [Authorize]

    [HttpPost("logout")]

    public async Task<IActionResult> Logout()

    {

        await HttpContext.SignOutAsync(

            CookieAuthenticationDefaults.AuthenticationScheme);



        HttpContext.Session.Clear();



        return Ok(new { message = "Logout successful." });

    }

}

