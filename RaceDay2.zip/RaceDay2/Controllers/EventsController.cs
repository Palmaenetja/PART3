﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Data;
using RaceDay.Models;
using RaceDay.Services;
using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
using System.Security.Claims;



namespace RaceDay.Controllers;



/// <summary>

/// Represents the information required to create or update an event.

/// </summary>

public class EventDto

{

    [Required, MaxLength(100)]

    public string Name { get; set; } = string.Empty;



    [MaxLength(1000)]

    public string Description { get; set; } = string.Empty;



    public DateTime Date { get; set; }



    [Required, MaxLength(150)]

    public string Location { get; set; } = string.Empty;



    [Range(typeof(decimal), "0.01", "1000")]

    public decimal DistanceKm { get; set; }



    [Required]

    [RegularExpression("^(Run|Walk|Cycle)$")]

    public string EventType { get; set; } = "Run";

}
/// <summary>

/// Creates and manages RaceDay events.

/// </summary>

[ApiController]

[Route("api/events")]

public class EventsController : ControllerBase

{

    private readonly RaceDayDbContext _db;



    public EventsController(RaceDayDbContext db) => _db = db;



    /// <summary>

    /// Returns events with their categories.

    /// </summary>

    [HttpGet]

    [AllowAnonymous]

    public async Task<IActionResult> GetEvents()

    {

        var events = await _db.Events

            .Include(e => e.Categories)

            .Select(e => new

            {

                e.EventId,

                e.Name,

                e.Description,

                e.Date,

                e.Location,

                e.DistanceKm,

                e.EventType,

                Categories = e.Categories.Select(c => new

                {

                    c.CategoryId,
                    c.Name,
                    c.Description

                })

            })

            .ToListAsync();



        return Ok(events);

    }



    /// <summary>

    /// Creates an event for the authenticated organiser.

    /// </summary>

    [HttpPost]

    [Authorize(Roles = "Organiser")]

    public async Task<IActionResult> CreateEvent(EventDto dto)

    {

        var organiserId = int.Parse(

            User.FindFirstValue(ClaimTypes.NameIdentifier)!);



        var item = new Models.Event

        {

            Name = dto.Name,

            Description = dto.Description,

            Date = dto.Date,

            Location = dto.Location,

            DistanceKm = dto.DistanceKm,

            EventType = dto.EventType,

            OrganizerId = organiserId

        };



        _db.Events.Add(item);

        await _db.SaveChangesAsync();



        return CreatedAtAction(

            nameof(GetEvents), new { id = item.EventId }, item);

    }



    /// <summary>

    /// Updates an event owned by the current organiser.

    /// </summary>

    [HttpPut("{id:int}")]

    [Authorize(Roles = "Organiser")]

    public async Task<IActionResult> UpdateEvent(

        int id, EventDto dto)

    {

        var organiserId = int.Parse(

            User.FindFirstValue(ClaimTypes.NameIdentifier)!);



        var item = await _db.Events.SingleOrDefaultAsync(e =>

            e.EventId == id && e.OrganizerId == organiserId);



        if (item is null) return NotFound();



        item.Name = dto.Name;

        item.Description = dto.Description;

        item.Date = dto.Date;

        item.Location = dto.Location;

        item.DistanceKm = dto.DistanceKm;

        item.EventType = dto.EventType;



        await _db.SaveChangesAsync();

        return NoContent();

    }

    public string? BannerImageUrl { get; set; }

    /// <summary>

    /// Deletes an event owned by the current organiser.

    /// </summary>

    [HttpDelete("{id:int}")]

    [Authorize(Roles = "Organiser")]

    public async Task<IActionResult> DeleteEvent(int id)

    {

        var organiserId = int.Parse(

            User.FindFirstValue(ClaimTypes.NameIdentifier)!);



        var item = await _db.Events.SingleOrDefaultAsync(e =>

            e.EventId == id && e.OrganizerId == organiserId);



        if (item is null) return NotFound();



        if (await _db.Enrollments.AnyAsync(e => e.EventId == id))

            return Conflict(

                "Events with enrolments cannot be deleted.");



        _db.Events.Remove(item);

        await _db.SaveChangesAsync();



        return NoContent();

    }
    [HttpPost("{eventId:int}/banner")]
    [Authorize(Roles = "Organiser")]
    [Consumes("multipart/form-data")]
    public async Task<IActionResult> UploadBanner(
    int eventId,
    IFormFile file,
    [FromServices] BlobStorageService storage)
    {
        var userId = User.FindFirstValue(
        System.Security.Claims.ClaimTypes.NameIdentifier);
        if (!int.TryParse(userId, out var organiserId))
            return Unauthorized();
        var eventItem = await _db.Events
        .SingleOrDefaultAsync(e =>
        e.EventId == eventId &&
        e.OrganizerId == organiserId);
        if (eventItem == null)
            return NotFound("Event not found.");
        if (file == null)
            return BadRequest("Select an image.");
        try
        {
            var imageUrl =
            await storage.UploadImageAsync(file);
            eventItem.BannerImageUrl = imageUrl;
            await _db.SaveChangesAsync();
            return Ok(new
            {
                message = "Banner uploaded successfully.",
                imageUrl
            });
        }
        catch (ArgumentException ex)
        {
            return BadRequest(new { error = ex.Message });
        }
    }
    

}



