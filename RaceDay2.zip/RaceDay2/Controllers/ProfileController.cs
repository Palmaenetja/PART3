﻿using System.Security.Claims;

using Microsoft.AspNetCore.Authorization;

using Microsoft.AspNetCore.Mvc;

using Microsoft.EntityFrameworkCore;
using RaceDay.Models;
using RaceDay.Data;

namespace RaceDay.Controllers;



/// <summary>

/// Allows authenticated users to view and update their own profiles.

/// </summary>

[ApiController]

[Route("api/profile")]

[Authorize]

public class ProfileController : ControllerBase

{

    private readonly RaceDayDbContext _db;



    public ProfileController(RaceDayDbContext db) => _db = db;



    /// <summary>

    /// Returns the current user's account and participant details.

    /// </summary>

    [HttpGet("me")]

    public async Task<IActionResult> GetProfile()

    {

        var id = int.Parse(User.FindFirstValue(

            ClaimTypes.NameIdentifier)!);



        var user = await _db.Users

            .Include(u => u.Participant)

            .Where(u => u.UserId == id)

            .Select(u => new

            {

                u.UserId,

                u.Username,

                u.Email,

                u.Role,

                Participant = u.Participant == null ? null :

                    new

                    {

                        u.Participant.FirstName,

                        u.Participant.LastName,

                        u.Participant.DateOfBirth

                    }

            })

            .SingleOrDefaultAsync();



        return user is null ? NotFound() : Ok(user);

    }



    /// <summary>

    /// Updates the current user's email and, for participants,

    /// their personal details.

    /// </summary>

    [HttpPut("me")]

    public async Task<IActionResult> UpdateProfile(

        UpdateProfileDto dto)

    {

        var id = int.Parse(User.FindFirstValue(

            ClaimTypes.NameIdentifier)!);



        var user = await _db.Users

            .Include(u => u.Participant)

            .SingleOrDefaultAsync(u => u.UserId == id);



        if (user is null) return NotFound();



        if (await _db.Users.AnyAsync(u =>

            u.UserId != id && u.Email == dto.Email))

        {

            return Conflict("Email is already in use.");

        }



        user.Email = dto.Email.Trim();



        if (user.Participant is not null)

        {

            user.Participant.FirstName = dto.FirstName.Trim();

            user.Participant.LastName = dto.LastName.Trim();

        }



        await _db.SaveChangesAsync();

        return NoContent();

    }

}



/// <summary>

/// Contains fields that users may change on their own profiles.

/// </summary>

public class UpdateProfileDto

{

    [System.ComponentModel.DataAnnotations.Required]

    [System.ComponentModel.DataAnnotations.EmailAddress]

    public string Email { get; set; } = string.Empty;



    [System.ComponentModel.DataAnnotations.Required]

    public string FirstName { get; set; } = string.Empty;



    [System.ComponentModel.DataAnnotations.Required]

    public string LastName { get; set; } = string.Empty;

}
