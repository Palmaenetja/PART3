﻿using System.Security.Claims;

using Microsoft.AspNetCore.Authorization;

using Microsoft.AspNetCore.Mvc;

using Microsoft.EntityFrameworkCore;
using RaceDay.DTOs;

using RaceDay.Models;
using RaceDay.Data;

namespace RaceDay.Controllers;



/// <summary>

/// Manages event categories for RaceDay events.

/// Organisers manage categories for their own events,

/// while the public can view available categories.

/// </summary>

[ApiController]

[Route("api")]

public class CategoriesController : ControllerBase

{

    private readonly RaceDayDbContext _db;



    public CategoriesController(RaceDayDbContext db)

    {

        _db = db;

    }



    /// <summary>

    /// Retrieves all categories belonging to an event.

    /// </summary>

    [HttpGet("events/{eventId:int}/categories")]

    [AllowAnonymous]

    public async Task<IActionResult> GetCategories(int eventId)

    {

        var categories = await _db.Categories

            .Where(c => c.EventId == eventId)

            .Select(c => new

            {

                c.CategoryId,

                c.EventId,

                c.Name,

                c.Description,

                c.MinimumAge,

                c.MaximumAge,

                c.DistanceKm

            })

            .ToListAsync();



        return Ok(categories);

    }



    /// <summary>

    /// Retrieves a category by its identifier.

    /// </summary>

    [HttpGet("categories/{id:int}")]

    [AllowAnonymous]

    public async Task<IActionResult> GetCategory(int id)

    {

        var category = await _db.Categories

            .Where(c => c.CategoryId == id)

            .Select(c => new

            {

                c.CategoryId,

                c.EventId,

                c.Name,

                c.Description,

                c.MinimumAge,

                c.MaximumAge,

                c.DistanceKm

            })

            .SingleOrDefaultAsync();



        if (category is null)

            return NotFound("Category not found.");



        return Ok(category);

    }



    /// <summary>

    /// Creates a category for an event owned by the organiser.

    /// </summary>

    [HttpPost("events/{eventId:int}/categories")]

    [Authorize(Roles = "Organiser")]

    public async Task<IActionResult> CreateCategory(

        int eventId, CategoryDto dto)

    {

        var organiserId = int.Parse(

            User.FindFirstValue(ClaimTypes.NameIdentifier)!);



        var eventExists = await _db.Events.AnyAsync(e =>

            e.EventId == eventId &&

            e.OrganizerId == organiserId);



        if (!eventExists)

            return NotFound("Event not found or not owned by you.");



        var category = new Category

        {

            EventId = eventId,

            Name = dto.Name,

            Description = dto.Description,

            MinimumAge = dto.MinimumAge,

            MaximumAge = dto.MaximumAge,

            DistanceKm = dto.DistanceKm

        };



        _db.Categories.Add(category);

        await _db.SaveChangesAsync();



        return CreatedAtAction(

            nameof(GetCategory),

            new { id = category.CategoryId },

            new

            {

                category.CategoryId,

                category.EventId,

                category.Name,

                category.Description,

                category.MinimumAge,

                category.MaximumAge,

                category.DistanceKm

            });

    }



    /// <summary>

    /// Updates a category belonging to the organiser's event.

    /// </summary>

    [HttpPut("categories/{id:int}")]

    [Authorize(Roles = "Organiser")]

    public async Task<IActionResult> UpdateCategory(

        int id, CategoryDto dto)

    {

        var organiserId = int.Parse(

            User.FindFirstValue(ClaimTypes.NameIdentifier)!);



        var category = await _db.Categories

            .Include(c => c.Event)

            .SingleOrDefaultAsync(c =>

                c.CategoryId == id &&

                c.Event.OrganizerId == organiserId);



        if (category is null)

            return NotFound("Category not found or not owned by you.");



        category.Name = dto.Name;

        category.Description = dto.Description;

        category.MinimumAge = dto.MinimumAge;

        category.MaximumAge = dto.MaximumAge;

        category.DistanceKm = dto.DistanceKm;



        await _db.SaveChangesAsync();



        return NoContent();

    }



    /// <summary>

    /// Deletes a category belonging to the organiser's event.

    /// </summary>

    [HttpDelete("categories/{id:int}")]

    [Authorize(Roles = "Organiser")]

    public async Task<IActionResult> DeleteCategory(int id)

    {

        var organiserId = int.Parse(

            User.FindFirstValue(ClaimTypes.NameIdentifier)!);



        var category = await _db.Categories

            .Include(c => c.Event)

            .SingleOrDefaultAsync(c =>

                c.CategoryId == id &&

                c.Event.OrganizerId == organiserId);



        if (category is null)

            return NotFound("Category not found or not owned by you.");



        if (await _db.Enrollments.AnyAsync(e =>

            e.CategoryId == id))

        {

            return Conflict(

                "Cannot delete a category that has enrolments.");

        }



        _db.Categories.Remove(category);

        await _db.SaveChangesAsync();



        return NoContent();

    }

}


