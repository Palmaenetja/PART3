﻿
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
namespace RaceDay.Services;
/// <summary>
/// Handles image uploads to Azure Blob Storage.
/// </summary>
public class BlobStorageService
{
    private readonly BlobContainerClient _container;
    public BlobStorageService(IConfiguration configuration)
    {
        var connectionString =
        configuration["AzureBlobStorage:ConnectionString"]
        ?? throw new InvalidOperationException(
        "Azure Blob Storage connection string is missing.");
        var containerName =
        configuration["AzureBlobStorage:ContainerName"]
        ?? "raceday-images";
        var serviceClient =
        new BlobServiceClient(connectionString);
        _container =
        serviceClient.GetBlobContainerClient(containerName);
    }
    public async Task<string> UploadImageAsync(
    IFormFile file)
    {
        var extension =
        Path.GetExtension(file.FileName).ToLowerInvariant();
        var allowedExtensions =
        new[] { ".jpg", ".jpeg", ".png", ".webp" };
        if (!allowedExtensions.Contains(extension))
            throw new ArgumentException(
            "Only JPG, PNG and WEBP images are allowed.");
        if (file.Length <= 0 || file.Length > 5 * 1024 * 1024)
            throw new ArgumentException(
            "Image must be between 1 byte and 5 MB.");
        var allowedContentTypes = new[]
        {
"image/jpeg",
"image/png",
"image/webp"
};
        if (!allowedContentTypes.Contains(
        file.ContentType.ToLowerInvariant()))
        {
            throw new ArgumentException(
            "Invalid image content type.");
        }
        await _container.CreateIfNotExistsAsync();
        var blobName =
        $"{Guid.NewGuid()}{extension}";
        var blob = _container.GetBlobClient(blobName);
        await using var stream = file.OpenReadStream();
        await blob.UploadAsync(
        stream,
        new BlobHttpHeaders
        {
            ContentType = file.ContentType
        });
        return blob.Uri.ToString();
    }
}
