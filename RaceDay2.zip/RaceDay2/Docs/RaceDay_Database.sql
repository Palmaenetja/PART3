
CREATE TABLE Users (

user_id INT PRIMARY KEY IDENTITY(1,1),

username NVARCHAR(50) NOT NULL UNIQUE,

password_hash NVARCHAR(255) NOT NULL,

email NVARCHAR(100) NOT NULL UNIQUE,

role NVARCHAR(20) NOT NULL CHECK (role IN ('Organizer', 'Participant'))

);


CREATE TABLE Categories (

category_id INT PRIMARY KEY IDENTITY(1,1),

name NVARCHAR(50) NOT NULL,

description NVARCHAR(255)

);


CREATE TABLE Events (

event_id INT PRIMARY KEY IDENTITY(1,1),

name NVARCHAR(100) NOT NULL,

date DATETIME NOT NULL,

location NVARCHAR(100) NOT NULL,

organizer_id INT NOT NULL,

category_id INT NOT NULL,

FOREIGN KEY (organizer_id) REFERENCES Users(user_id),

FOREIGN KEY (category_id) REFERENCES Categories(category_id)

);


CREATE TABLE Participants (

participant_id INT PRIMARY KEY IDENTITY(1,1),

user_id INT NOT NULL,

first_name NVARCHAR(50) NOT NULL,

last_name NVARCHAR(50) NOT NULL,

date_of_birth DATE NOT NULL,

FOREIGN KEY (user_id) REFERENCES Users(user_id)

);


CREATE TABLE Enrollments (

enrollment_id INT PRIMARY KEY IDENTITY(1,1),

event_id INT NOT NULL,

participant_id INT NOT NULL,

registration_date DATETIME NOT NULL DEFAULT GETDATE(),

result NVARCHAR(50),

FOREIGN KEY (event_id) REFERENCES Events(event_id),

FOREIGN KEY (participant_id) REFERENCES Participants(participant_id)

);


CREATE TABLE Performances (

performance_id INT PRIMARY KEY IDENTITY(1,1),

participant_id INT NOT NULL,

event_id INT NOT NULL,

time NVARCHAR(10),

position INT,

FOREIGN KEY (participant_id) REFERENCES Participants(participant_id),

FOREIGN KEY (event_id) REFERENCES Events(event_id)

);


-- Sample Data

INSERT INTO Users (username, password_hash, email, role) VALUES

('Pal', 'ST10101777', 'ST10101777@RCCONNECT.com', 'Organizer'),

('Caroline', 'LOveRush', 'Carol1@gmail.com', 'Participant');


INSERT INTO Categories (name, description) VALUES

('Marathon', '50km road race'),

('Cycling', 'Cycling events');


INSERT INTO Events (name, date, location, organizer_id, category_id) VALUES

('Comrades Marathon', '2026-09-24', 'Soweto', 1, 1),

('Cape Town Cycle Tour', '2026-12-01', 'Cape Town', 1, 2);


INSERT INTO Participants (user_id, first_name, last_name, date_of_birth) VALUES

(2, 'Randy', 'Manroe', '1997-06-03');


INSERT INTO Enrollments (event_id, participant_id) VALUES

(1, 1);


INSERT INTO Performances (participant_id, event_id, time, position) VALUES

(1, 1, '02:55:40', 3);



